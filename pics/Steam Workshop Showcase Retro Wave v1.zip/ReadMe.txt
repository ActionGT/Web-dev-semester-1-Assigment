
Steam Workshop Showcase - Retro Wave v1

^----------------------------------------------------------------^

It's a free Workshop Showcase for your Steam Profile.
You must have reach Steam Level 10 so you can use the Workshop Showcase in your Profile
and you need the Artwork files from zip file you just downloaded.

You need to follow Step 2 (Upload to Steam) of this Guide, to let the pictures shown up correctly:

https://steamcommunity.com/sharedfiles/filedetails/?id=2174159512

Feel free to credit me on your Steam Profile if you using my Design, it would be nice.

Thank you.

^----------------------------------------------------------------^

My Steam: https://steamcommunity.com/id/qenoxis
My DeviantArt: https://www.deviantart.com/qenoxis
My ko-fi: https://ko-fi.com/qenoxis
My Gumroad: https://gumroad.com/qenoxis